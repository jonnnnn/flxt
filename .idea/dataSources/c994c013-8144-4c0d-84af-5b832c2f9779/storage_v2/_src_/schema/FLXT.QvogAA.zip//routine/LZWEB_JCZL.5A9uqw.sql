create procedure lzweb_jczl as
/*鲁仲小账本程序所需基础资料*/
begin
/*  客户*/
merge into scott.CUSTMAIN a
using (
 select CUSTNO, custname, custadd,CUSTIDENTIFY,LASTMODIFYTIME  from CUSTMAIN a
where   CUSTIDENTIFY like '%器械%'
and a.lastmodifytime > sysdate - 3
) b on (a.custno = b.custno )
when matched then
  update  set a.CUSTNAME = b.custname,a.CUSTADD=b.CUSTADD,a.CUSTIDENTIFY = b.custidentify,a.LASTMODIFYTIME = b.lastmodifytime where a.LASTMODIFYTIME <> b.lastmodifytime
when not matched then
  insert (custno,custname,custadd,CUSTIDENTIFY) values (b.custno,b.custname,b.custadd,b.custidentify) ;
commit;
/*商品*/
  merge into scott.prodmain a
using (
 select PRODNO, PRODNAME, PRODSPECIFICATION,PACKAGEUNIT,MANUFACTURE,APPROVALNO,STERILIZATION,LASTMODIFYTIME,BUSITYPE  from prodmain a
where  BUSITYPE = 'QX'
and a.lastmodifytime > sysdate - 3
) b on (a.PRODNO = b.PRODNO )
when matched then
  update  set a.PRODNAME = b.PRODNAME,a.PRODSPECIFICATION=b.PRODSPECIFICATION,a.PACKAGEUNIT = b.PACKAGEUNIT,a.MANUFACTURE=b.MANUFACTURE,a.APPROVALNO=b.APPROVALNO,a.STERILIZATION=b.STERILIZATION,a.LASTMODIFYTIME = b.lastmodifytime  where a.LASTMODIFYTIME <> b.lastmodifytime
when not matched then
  insert (PRODNO,PRODNAME,PRODSPECIFICATION,PACKAGEUNIT,MANUFACTURE,APPROVALNO,STERILIZATION,lastmodifytime) values (b.PRODNO,b.PRODNAME,b.PRODSPECIFICATION,b.PACKAGEUNIT,b.MANUFACTURE,b.APPROVALNO,b.STERILIZATION,b.lastmodifytime) ;
 commit;
 end;
/

