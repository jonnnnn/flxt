create view VW_YLR as
  select createtime        单据日期,
       note              备注,
       billid            单据编号,
       statu             状态_初始_采购审核_已记账_驳回,
       begindate         政策开始日期,
       enddate           政策截止日期,
       supno             供应商编码,
       supname           供应商名称,
       prodno            商品编码,
       prodname          商品名称,
       prodspecification 规格,
       packageunit       包装单位,
       custno            客户编码,
       custname          客户名称,
       price             销售价,
       getprice          购进价,
       flmark            返利政策详情,
       fltype            返利类型,
       flprice           返利单价,
       dftime            兑付时间,
       dftype            兑付方式,
       contactsman       联系人,
       contactsphone     联系人电话,
       note2             实收金额,
       staff             制单人,
       purchaser         采购员,
       branchid          公司标识,
       ownerareatext     所属大区
  from YLR t
 where DELETEFLAG = 0
/

